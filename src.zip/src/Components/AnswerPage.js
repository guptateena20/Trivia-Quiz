import React, { useEffect } from 'react'
import CommonCode from './CommonCode'
import "../Styles/Answerspage/Answerspage.css"
import questions from './QuizData'
import { useNavigate } from 'react-router-dom'



const AnswerPage = () => {
  const navigate = useNavigate();
  
 const handleClick = () => {
    navigate("/", {replace : true});
 }

  return (
    <>
      <div className='main_container'>
        <div className='inner_container'>

          <CommonCode />
          <div className='answerpage_footer_div'>
            <p className='answerpage_footer_para'>You scored 3/{questions.length} correct answers</p>
            <button className='answerpage_btn' onClick={handleClick}>Play again</button>
          </div>
        </div>
      </div>
    </>
  )
}

export default AnswerPage