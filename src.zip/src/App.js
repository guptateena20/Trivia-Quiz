import {Routes, Route} from "react-router-dom"
import './App.css';
import Startpage from './Components/Startpage';
import QuizPage from './Components/QuizPage';
import AnswerPage from './Components/AnswerPage';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path = "/" element = {<Startpage/>}/>
        <Route path = "quiz" element = {<QuizPage/>}/>
        <Route path = "answer" element = {<AnswerPage/>}/>
      </Routes>
    </div>
  );
}

export default App;
